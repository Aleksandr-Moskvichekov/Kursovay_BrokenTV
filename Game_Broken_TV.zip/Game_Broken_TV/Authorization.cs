﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Game_Broken_TV
{
    public partial class Authorization : Form
    {

       

        public Authorization()
        {
            InitializeComponent();

           
        }

       
        private void Authentication_Load(object sender, EventArgs e)
        {
            

           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void WordLable_Click(object sender, EventArgs e)
        {

        }

        private void SingIn_Click(object sender, EventArgs e)
        {
      

            string username = Login.Text;
            string password = Password.Text;

            if (AuthorizationCheck(username,password))
            {
                
                this.Hide();
                Form1 f1 = new Form1(username);
                f1.ShowDialog();
                this.Close();
            }
        }

        public bool AuthorizationCheck(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                // Вместо MessageBox можно выбрасывать исключение или логировать ошибку
                MessageBox.Show("Введите логин и пароль","Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else
            {
                string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + AppDomain.CurrentDomain.BaseDirectory.Substring(0, AppDomain.CurrentDomain.BaseDirectory.Length - 10) + "Data.mdf;Integrated Security=True";
                //string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\USERS\\ALEKSANDR\\DOCUMENTS\\УЧЕБА\\2 КУРС\\КУРСОВАЯ РАБОТА\\GAME_BROKEN_TV\\DATA.MDF;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT Password FROM [Players] WHERE Login = @Login";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Login", username);

                        connection.Open();
                        string savedPassword = command.ExecuteScalar() as string;

                        if (password == savedPassword)
                        {
                            return true;
                        }
                        else
                        {
                            MessageBox.Show("Неверно введен логин или пароль","Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                    }
                }
            }
        }


        private void Reg_Click(object sender, EventArgs e)
        {


            this.Hide();
            Registration Reg = new Registration();
            Reg.ShowDialog();
            this.Close();
        }
    }
}
