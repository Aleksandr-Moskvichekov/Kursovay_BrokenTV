﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Game_Broken_TV
{
    public partial class Registration : Form
    {
        
        public Registration()
        {
            InitializeComponent();
        }

        private void WordLable_Click(object sender, EventArgs e)
        {

        }

        
        private void Reg_Click(object sender, EventArgs e)
        {
            label1.ForeColor = Color.Black;
            label2.ForeColor = Color.Black;
            label3.ForeColor = Color.Black;

            label2.Text = "Введите пароль";
            label3.Text = "Повторите пароль";
            

            string username = Login.Text;
            string password = Password.Text;
            string password2 = SecondPassword.Text;
            
            if (Registration_Chek(username,password,password2))
            {
                
                //вставить бд
                SqlCommand cmd = new SqlCommand($"INSERT INTO [Players] (Login, Password) VALUES (N'{username}', N'{password}')", sqlConnection);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Регистрация успешна", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                sqlConnection.Close();
                this.Hide();
                Authorization A = new Authorization();
                A.ShowDialog();
                this.Close();
            }
        }

        public bool Registration_Chek(string username, string password, string password2)
        {
            bool notNull = false;
            bool Len8 = false;
            bool Ecvel = false;

            if (!String.IsNullOrEmpty(username) && !String.IsNullOrEmpty(password) && !String.IsNullOrEmpty(password2))
            {
                notNull = true;
            }

            bool userExists = false;

            using (SqlCommand userExistsCommand = new SqlCommand($"SELECT COUNT(1) FROM [Players] WHERE Login = '{username}'", sqlConnection))
            {
                int userCount = (int)userExistsCommand.ExecuteScalar();
                userExists = userCount > 0;
            }

            if (userExists)
            {
                MessageBox.Show("Пользователь с таким именем уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            else
            {
                if (String.IsNullOrEmpty(username))
                {
                    label1.ForeColor = Color.Red;
                }
                else
                {
                    label1.ForeColor = Color.Green;
                }
                if (String.IsNullOrEmpty(password))
                {
                    label2.ForeColor = Color.Red;
                }
                else
                {
                    label2.ForeColor = Color.Green;
                }
                if (String.IsNullOrEmpty(password2))
                {
                    label3.ForeColor = Color.Red;
                }
                else
                {
                    label3.ForeColor = Color.Green;
                }

            }

            if (password == password2)
            {
                Ecvel = true;
            }
            else
            {
                label3.Text = "Пароли не совпадают";
                label3.ForeColor = Color.Red;
            }

            if (password.Length >= 8 && password2.Length >= 8 && password.Length <= 50 && password2.Length <= 50)
            {
                Len8 = true;
            }
            else
            {
                label2.Text = "Длина пароля от 8 до 50 символов";
                label3.Text = "Длина пароля от 8 до 50 символов";
                label2.ForeColor = Color.Red;
                label3.ForeColor = Color.Red;
            }

            if (notNull && Ecvel && Len8)
            {

                return true;
            }
            else { return false; }
        }

        private SqlConnection sqlConnection = null;
        private void Registration_Load(object sender, EventArgs e)
        {


            sqlConnection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + AppDomain.CurrentDomain.BaseDirectory.Substring(0, AppDomain.CurrentDomain.BaseDirectory.Length - 10) + "Data.mdf;Integrated Security=True");

            sqlConnection.Open();
            /*
            if (sqlConnection.State == ConnectionState.Open)
            {
                MessageBox.Show("Подключено");

            }
            */
        }

        public bool Registration_Chek()
        {
            throw new NotImplementedException();
        }
    }
}
