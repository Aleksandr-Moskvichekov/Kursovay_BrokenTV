﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Game_Broken_TV
{
    public partial class Form1 : Form
    {
        bool startgame;
        static int ansver = 0;
        Random Random = new Random();
        int time;
        string User = null;
        string LastWord = "";

        string[] Words = { "Зеленый", "Синий", "Красный", "Желтый", "Оранжевый", "Фиалетовый" };
        int[,,] Colors = {
           { {255, 0, 0},      // Красный
      {0, 255, 0},      // Зеленый
      {0, 0, 255},      // Синий
      {255, 255, 0},    // Желтый
      {0, 255, 255},    // Бирюзовый
      {255, 0, 255},    // Пурпурный
      {255, 128, 0},    // Оранжевый
      {128, 255, 0},    // Лайм
      {0, 128, 255},    // Голубой
      {0, 255, 128},    // Бирюзовый
      {128, 0, 255},    // Фиолетовый
      {255, 128, 128},  // Розовый
      {128, 255, 128},  // Светло-зеленый
      {128, 128, 255},  // Светло-синий
      {255, 0, 128},    // Темно-розовый
      {255, 128, 0},    // Темно-оранжевый
      {128, 0, 255}     // Темно-фиолетовый
    }
        };


        //int[,,] Colors = { { {255 , 2, 3 }, { 4, 255, 6 }, { 1, 2, 255 },{120,120,0 }, { 0, 130, 130 },{ 130, 0, 130 },{183,28,28 },{136,79,14 },{74,140,20 },{49,146,27 },{1,155,87 },{0,64,77 },{0,100,96},{130,23,119 },{245,23,127},{230,0,81},{63,35,39} } };
        string Word;
        public Form1(string Name)
        {
            User = Name;
            InitializeComponent();
            WordLable.Hide();
        }

        public static int Ff()
        {
            return ansver;
        }
        private void start()
        {
            WordLable.Show();
            startgame = true;
            time = 60;
            timelabel.Text = time + " Секунд";
            timer1.Interval = 1000;
            timer1.Start();
            BackColor = Color.LightCyan;
            NewWord();
        }

        private void NewWord()
        {
            int rnd = Random.Next(Words.Length);
            int RndColors = Random.Next(16);
            int BackRndColors = Random.Next(16);
            while(LastWord == Words[rnd])
            {
                rnd = Random.Next(Words.Length);
            }
            Word = Words[rnd];
            WordLable.Text = Word;
            LastWord = Words[rnd];
            WordLable.ForeColor = System.Drawing.Color.FromArgb(Colors[0, RndColors, 0], Colors[0,RndColors,1],Colors[0, RndColors, 2]);


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void OrangeButton_Click(object sender, EventArgs e)
        {
            string BtnWord = Words[4];
            if (startgame)
            {
                if (Word == BtnWord)
                {
                    ansver += 1;
                }
                NewWord();
            }
        }

        private void RedButton_Click(object sender, EventArgs e)
        {
            string BtnWord = Words[2];
            if (startgame)
            {
                if (Word == BtnWord)
                {
                    ansver += 1;
                }
                NewWord();
            }
        }

        private void YellouButton_Click(object sender, EventArgs e)
        {
            string BtnWord = Words[3];
            if (startgame)
            {
                if (Word == BtnWord)
                {
                    ansver += 1;
                }
                NewWord();
            }
        }

        private void GreenButton_Click(object sender, EventArgs e)
        {
            string BtnWord = Words[0];
            if (startgame)
            {
                if (Word == BtnWord)
                {
                    ansver += 1;
                }
                NewWord();
            }
        }

        private void VioletButton_Click(object sender, EventArgs e)
        {
            string BtnWord = Words[5];
            if (startgame)
            {
                if (Word == BtnWord)
                {
                    ansver += 1;
                }
                NewWord();
            }
        }

        private void BlueButtton_Click(object sender, EventArgs e)
        {
            string BtnWord = Words[1];
            if (startgame)
            {
                if (Word == BtnWord)
                {
                    ansver += 1;
                }
                NewWord();
            }
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time -= 1;
            timelabel.Text = time + " Секунд";
            Ansver.Text = "Правильных ответов "+ansver;
            if (time == 0) 
            {
                timer1.Stop();
                startgame = false;
                MessageBox.Show("Игра Окончена");
                //отправка результатов в бд
                int LastBestTry = 0;
                SqlCommand sqlCommand = new SqlCommand($"SELECT BestTry FROM [Players] WHERE Login = '{User}'", sqlConnection);

                SqlDataReader reader = sqlCommand.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    LastBestTry = (int)reader[0];
                }
                reader.Close();

                if (LastBestTry < ansver)
                {
                    SqlCommand cmd = new SqlCommand($"UPDATE [Players] SET BestTry = N'{ansver}' WHERE Login='{User}'", sqlConnection);

                    cmd.ExecuteNonQuery();
                }

                sqlConnection.Close();
                this.Hide();
                Results R = new Results(ansver,User);
                R.ShowDialog();
                this.Close();
            }
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private SqlConnection sqlConnection = null;
        private void Form1_Load(object sender, EventArgs e)
        {
            ansver = 0;

            sqlConnection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + AppDomain.CurrentDomain.BaseDirectory.Substring(0, AppDomain.CurrentDomain.BaseDirectory.Length - 10) + "Data.mdf;Integrated Security=True");

            sqlConnection.Open();
            /*
            if (sqlConnection.State == ConnectionState.Open)
            {
                MessageBox.Show("Подключено");

            }
            */
        }

        private void Start_Batton_Click(object sender, EventArgs e)
        {
            start();
            Start_Batton.Hide();
            
        }
    }
}
