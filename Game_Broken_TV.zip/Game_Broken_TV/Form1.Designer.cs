﻿namespace Game_Broken_TV
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timelabel = new System.Windows.Forms.Label();
            this.BlueButtton = new System.Windows.Forms.Button();
            this.RedButton = new System.Windows.Forms.Button();
            this.YellouButton = new System.Windows.Forms.Button();
            this.GreenButton = new System.Windows.Forms.Button();
            this.OrangeButton = new System.Windows.Forms.Button();
            this.VioletButton = new System.Windows.Forms.Button();
            this.WordLable = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Ansver = new System.Windows.Forms.Label();
            this.Start_Batton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // timelabel
            // 
            this.timelabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.timelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timelabel.CausesValidation = false;
            this.timelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.timelabel.Location = new System.Drawing.Point(12, 99);
            this.timelabel.MaximumSize = new System.Drawing.Size(200, 30);
            this.timelabel.MinimumSize = new System.Drawing.Size(200, 30);
            this.timelabel.Name = "timelabel";
            this.timelabel.Size = new System.Drawing.Size(200, 30);
            this.timelabel.TabIndex = 0;
            this.timelabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // BlueButtton
            // 
            this.BlueButtton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BlueButtton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BlueButtton.Location = new System.Drawing.Point(334, 234);
            this.BlueButtton.MaximumSize = new System.Drawing.Size(120, 40);
            this.BlueButtton.MinimumSize = new System.Drawing.Size(120, 40);
            this.BlueButtton.Name = "BlueButtton";
            this.BlueButtton.Size = new System.Drawing.Size(120, 40);
            this.BlueButtton.TabIndex = 1;
            this.BlueButtton.Text = "Синий";
            this.BlueButtton.UseVisualStyleBackColor = true;
            this.BlueButtton.Click += new System.EventHandler(this.BlueButtton_Click);
            // 
            // RedButton
            // 
            this.RedButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.RedButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RedButton.Location = new System.Drawing.Point(208, 232);
            this.RedButton.MaximumSize = new System.Drawing.Size(120, 40);
            this.RedButton.MinimumSize = new System.Drawing.Size(120, 40);
            this.RedButton.Name = "RedButton";
            this.RedButton.Size = new System.Drawing.Size(120, 40);
            this.RedButton.TabIndex = 2;
            this.RedButton.Text = "Красный";
            this.RedButton.UseVisualStyleBackColor = true;
            this.RedButton.Click += new System.EventHandler(this.RedButton_Click);
            // 
            // YellouButton
            // 
            this.YellouButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.YellouButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.YellouButton.Location = new System.Drawing.Point(460, 234);
            this.YellouButton.MaximumSize = new System.Drawing.Size(120, 40);
            this.YellouButton.MinimumSize = new System.Drawing.Size(120, 40);
            this.YellouButton.Name = "YellouButton";
            this.YellouButton.Size = new System.Drawing.Size(120, 40);
            this.YellouButton.TabIndex = 3;
            this.YellouButton.Text = "Желтый";
            this.YellouButton.UseVisualStyleBackColor = true;
            this.YellouButton.Click += new System.EventHandler(this.YellouButton_Click);
            // 
            // GreenButton
            // 
            this.GreenButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GreenButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GreenButton.Location = new System.Drawing.Point(208, 295);
            this.GreenButton.MaximumSize = new System.Drawing.Size(120, 40);
            this.GreenButton.MinimumSize = new System.Drawing.Size(120, 40);
            this.GreenButton.Name = "GreenButton";
            this.GreenButton.Size = new System.Drawing.Size(120, 40);
            this.GreenButton.TabIndex = 4;
            this.GreenButton.Text = "Зелёный";
            this.GreenButton.UseVisualStyleBackColor = true;
            this.GreenButton.Click += new System.EventHandler(this.GreenButton_Click);
            // 
            // OrangeButton
            // 
            this.OrangeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OrangeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OrangeButton.Location = new System.Drawing.Point(334, 295);
            this.OrangeButton.MaximumSize = new System.Drawing.Size(120, 40);
            this.OrangeButton.MinimumSize = new System.Drawing.Size(120, 40);
            this.OrangeButton.Name = "OrangeButton";
            this.OrangeButton.Size = new System.Drawing.Size(120, 40);
            this.OrangeButton.TabIndex = 5;
            this.OrangeButton.Text = "Оранжевый";
            this.OrangeButton.UseVisualStyleBackColor = true;
            this.OrangeButton.Click += new System.EventHandler(this.OrangeButton_Click);
            // 
            // VioletButton
            // 
            this.VioletButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.VioletButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.VioletButton.Location = new System.Drawing.Point(460, 295);
            this.VioletButton.MaximumSize = new System.Drawing.Size(120, 40);
            this.VioletButton.MinimumSize = new System.Drawing.Size(120, 40);
            this.VioletButton.Name = "VioletButton";
            this.VioletButton.Size = new System.Drawing.Size(120, 40);
            this.VioletButton.TabIndex = 6;
            this.VioletButton.Text = "Фиалетовый";
            this.VioletButton.UseVisualStyleBackColor = true;
            this.VioletButton.Click += new System.EventHandler(this.VioletButton_Click);
            // 
            // WordLable
            // 
            this.WordLable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WordLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WordLable.Location = new System.Drawing.Point(318, 156);
            this.WordLable.Name = "WordLable";
            this.WordLable.Size = new System.Drawing.Size(213, 37);
            this.WordLable.TabIndex = 7;
            this.WordLable.Text = "---------";
            this.WordLable.Click += new System.EventHandler(this.label2_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Ansver
            // 
            this.Ansver.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Ansver.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Ansver.CausesValidation = false;
            this.Ansver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ansver.Location = new System.Drawing.Point(12, 139);
            this.Ansver.MaximumSize = new System.Drawing.Size(250, 30);
            this.Ansver.MinimumSize = new System.Drawing.Size(250, 30);
            this.Ansver.Name = "Ansver";
            this.Ansver.Size = new System.Drawing.Size(250, 30);
            this.Ansver.TabIndex = 8;
            this.Ansver.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Start_Batton
            // 
            this.Start_Batton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Start_Batton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Start_Batton.Location = new System.Drawing.Point(334, 153);
            this.Start_Batton.MaximumSize = new System.Drawing.Size(120, 40);
            this.Start_Batton.MinimumSize = new System.Drawing.Size(120, 40);
            this.Start_Batton.Name = "Start_Batton";
            this.Start_Batton.Size = new System.Drawing.Size(120, 40);
            this.Start_Batton.TabIndex = 9;
            this.Start_Batton.Text = "Начать";
            this.Start_Batton.UseVisualStyleBackColor = true;
            this.Start_Batton.Click += new System.EventHandler(this.Start_Batton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(808, 450);
            this.Controls.Add(this.Start_Batton);
            this.Controls.Add(this.Ansver);
            this.Controls.Add(this.WordLable);
            this.Controls.Add(this.VioletButton);
            this.Controls.Add(this.OrangeButton);
            this.Controls.Add(this.GreenButton);
            this.Controls.Add(this.YellouButton);
            this.Controls.Add(this.RedButton);
            this.Controls.Add(this.BlueButtton);
            this.Controls.Add(this.timelabel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BrokenTV";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label timelabel;
        private System.Windows.Forms.Button BlueButtton;
        private System.Windows.Forms.Button RedButton;
        private System.Windows.Forms.Button YellouButton;
        private System.Windows.Forms.Button GreenButton;
        private System.Windows.Forms.Button OrangeButton;
        private System.Windows.Forms.Button VioletButton;
        private System.Windows.Forms.Label WordLable;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label Ansver;
        private System.Windows.Forms.Button Start_Batton;
    }
}

