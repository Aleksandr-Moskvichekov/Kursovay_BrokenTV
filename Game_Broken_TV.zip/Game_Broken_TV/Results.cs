﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Game_Broken_TV
{
    public partial class Results : Form
    {
        private SqlConnection connection = null;
        SqlConnection sqlConnection = null;
        private string username;
        public Results(int Try, string User)
        {
            InitializeComponent();
            
            username = User;
            int LastBestTry = 0;
            Result.Text = Convert.ToString(Try);

            sqlConnection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + AppDomain.CurrentDomain.BaseDirectory.Substring(0, AppDomain.CurrentDomain.BaseDirectory.Length - 10) + "Data.mdf;Integrated Security=True");

            sqlConnection.Open();

            SqlCommand sqlCommand = new SqlCommand($"SELECT BestTry FROM [Players] WHERE Login = '{User}'", sqlConnection);

            SqlDataReader reader = sqlCommand.ExecuteReader();
            reader.Read();
            if (reader.HasRows)
            {
                LastBestTry = (int)reader[0];
            }
            reader.Close();
            label3.Text = LastBestTry.ToString();

            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Start_Batton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1(username);
            f1.ShowDialog();
            this.Close();
        }

        
        private void Results_Load(object sender, EventArgs e)
        {
            string ResultString = null;

            using (connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + AppDomain.CurrentDomain.BaseDirectory.Substring(0, AppDomain.CurrentDomain.BaseDirectory.Length - 10) + "Data.mdf;Integrated Security=True"))
            {
                // Открываем соединение
                connection.Open();

                // SQL запрос для выбора и сортировки данных
                string sqlQuery = "SELECT * FROM [Players] ORDER BY BestTry DESC";

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Создаем объект SqlDataReader для считывания данных
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Перебираем все строки возвращенного набора данных
                        while (reader.Read())
                        {
                            // Чтение столбцов "Username" и "BestTry"
                            string username = reader["Login"].ToString();
                            int bestTry = Convert.ToInt32(reader["BestTry"]);

                            // Вывод информации
                            ResultString += $"\n{username}:{bestTry}";
                        }
                    }
                }
            }
            label2.Text = ResultString;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
